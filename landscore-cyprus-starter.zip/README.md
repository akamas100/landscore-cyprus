# LandScore Cyprus Starter

Starter project structure for a GIS land analysis platform.

## Folders
- frontend/
- backend/

This is a scaffold to begin development.
